package ekam.example.web;

import com.testvagrant.ekam.testBases.testng.WebTest;
import org.testng.annotations.Test;
import static com.testvagrant.ekam.commons.LayoutInitiator.*;
import static org.testng.Assert.*;

@Test(groups = "web")
public class WebExampleTest extends WebTest {}

package ekam.example.api;

import com.testvagrant.ekam.testBases.testng.APITest;
import org.testng.annotations.Test;

@Test(groups = "api")
public class APIExampleTest extends APITest {}
